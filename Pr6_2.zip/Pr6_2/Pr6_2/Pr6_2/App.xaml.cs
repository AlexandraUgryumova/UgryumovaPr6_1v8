﻿using Pr6_2.Models;
using System;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using Pr6_2.Data;
using System.IO;

namespace Pr6_2
{
    public partial class App : Application
    {
        private static ClientDB db;
        private static ClientDB Db
        {
            get
            {
                if (db == null)
                    db = new ClientDB("db.sqlite1");
                return db;
            }
        }
        private static DetailDB db2;
        private static DetailDB Db2
        {
            get
            {
                if (db2 == null)
                    db2 = new DetailDB("db.sqlite2");
                return db2;
            }
        }
        private static MebelItemDB db3;
        private static MebelItemDB Db3
        {
            get
            {
                if (db3 == null)
                    db3 = new MebelItemDB("db.sqlite3");
                return db3;
            }
        }
        private static ZakazBD db4;
        private static ZakazBD Db4
        {
            get
            {
                if (db4 == null)
                    db4 = new ZakazBD("db.sqlite4");
                return db4;
            }
        }
        public App()
        {
            InitializeComponent();

            MainPage = new LoginPage();
        }

        protected override void OnStart()
        {
        }

        protected override void OnSleep()
        {
        }

        protected override void OnResume()
        {
        }
    }
}
