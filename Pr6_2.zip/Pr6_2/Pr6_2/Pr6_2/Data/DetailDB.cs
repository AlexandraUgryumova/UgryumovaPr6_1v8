﻿using System;
using System.Collections.Generic;
using System.Text;
using Pr6_2.Models;
using SQLite;

namespace Pr6_2.Data
{
    public class DetailDB
    {
        private readonly SQLiteConnection connection;
        public DetailDB(string path)
        {
            connection = new SQLiteConnection(path);
            connection.CreateTable<Client>();
        }
        public List<Detail> GetDetail()
        {
            return connection.Table<Detail>().ToList();
        }
        public int SaveDetail(Detail detail)
        {
            return connection.Insert(detail);
        }
    }
}
