﻿using Pr6_2.Models;
using SQLite;
using System;
using System.Collections.Generic;
using System.Text;

namespace Pr6_2.Data
{
    public class ZakazBD
    {
        private readonly SQLiteConnection connection;
        public ZakazBD(string path)
        {
            connection = new SQLiteConnection(path);
            connection.CreateTable<Zalaz>();
        }
        public List<Zalaz> GetZakaz()
        {
            return connection.Table<Zalaz>().ToList();
        }
        public int SaveZakaz(Zalaz zakaz)
        {
            return connection.Insert(zakaz);
        }
    }
}
