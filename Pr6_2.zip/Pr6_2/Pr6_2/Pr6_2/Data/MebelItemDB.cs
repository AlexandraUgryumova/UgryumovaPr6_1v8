﻿using System;
using System.Collections.Generic;
using System.Text;
using Pr6_2.Models;
using SQLite;

namespace Pr6_2.Data
{
    public class MebelItemDB
    {
        private readonly SQLiteConnection connection;
        public MebelItemDB(string path)
        {
            connection = new SQLiteConnection(path);
            connection.CreateTable<MebelItem>();
        }
        public List<MebelItem> GetMebel()
        {
            return connection.Table<MebelItem>().ToList();
        }
        public int SaveMebel(MebelItem mebel)
        {
            return connection.Insert(mebel);
        }
    }
}
