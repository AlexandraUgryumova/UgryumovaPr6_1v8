﻿using System;
using System.Collections.Generic;
using System.Text;
using SQLite;

namespace Pr6_2.Models
{
    public class Detail
    {
        [PrimaryKey, AutoIncrement]
        public int Id { get; set; }
        public string TypeDetail { get; set; }
        public string Manufacturer { get; set; }
    }
}
