﻿using System;
using System.Collections.Generic;
using System.Text;
using SQLite;

namespace Pr6_2.Models
{
    public class MebelItem
    {
        [PrimaryKey, AutoIncrement]
        public int Id { get; set; } 
        public string Name { get; set; }
        public string detales { get; set; }
        public string Photo { get; set; }
        public int Price { get; set; }

    }
}
