﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace Pr6_2
{
	[XamlCompilation(XamlCompilationOptions.Compile)]
	public partial class AddMebelPage : ContentPage
	{
		public AddMebelPage ()
		{
			InitializeComponent ();
		}
        private async void AddButton_Clicked(object sender, EventArgs e)
        {
            string title = titleField.Text.Trim();
            string desc = descField.Text.Trim();
            string image = imageField.Text.Trim();
            int price = Convert.ToInt32(priceField.Text.Trim());
            if(title.Length == 0)
            {
                await DisplayAlert("Ошибка", "нет названия", "ОК");
                return;
            }
            else if(title.Length == 0)
            {
                await DisplayAlert("Ошибка", "нет детали", "ОК");
                return;
            }
            else if (image.Length == 0)
            {
                await DisplayAlert("Ошибка", "нет картинки", "ОК");
                return;
            }
            else if (price < 300)
            {
                await DisplayAlert("Ошибка", "цена слишком маленькая", "ОК");
                return;
            }
            App.Db3.SaveMebel();
        }
    }
}